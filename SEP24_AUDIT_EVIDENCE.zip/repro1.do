clear all
set more off
set linesize 255
adopath ++ "/tmp/ctools-sep24-audit/build"
capture log close _all
log using "/tmp/ctools-sep24-audit/repro1.log", text replace
ctools, version

* Solver failure must not be represented as a converged estimate.
clear
set obs 1000
set seed 742913
gen g = ceil(_n/10)
gen h = ceil(runiform()*50)
gen double x = rnormal() + g/10 + h/5
gen double y = .7*x + g/5 - h/7 + rnormal()
capture noisily creghdfe y x, absorb(g h) iterate(1) tolerance(1e-14)
di "AUDIT OLS_ITER1_RC=" _rc
capture di "AUDIT OLS_ITER1_B=" _b[x]
capture noisily creghdfe y x, absorb(g h) tolerance(1e-12)
di "AUDIT OLS_CONVERGED_B=" _b[x]
replace y = rpoisson(exp(.3 + .05*x + g/200 + h/100))
capture noisily cpplmhdfe y x, absorb(g h) irlsmaxiter(1)
di "AUDIT PPML_ITER1_RC=" _rc
capture di "AUDIT PPML_ITER1_CONVERGED=" e(converged)

* Factor-variable prediction uncertainty.
clear
set obs 600
set seed 12568
gen g = mod(_n,3)
gen double x = rnormal()
gen double y = 2*x + g + (1+g)*rnormal()
cqreg y x i.g
predict double cs, stdp
_predict double correct, stdp
gen double diff = abs(cs-correct)
su diff, meanonly
di "AUDIT CQREG_STDP_MAXDIFF=" %21.15g r(max)
list g cs correct in 1/9

* Destructive output aliases.
clonevar before_x = x
capture noisily creghdfe y x, residuals(x)
local result = _rc
count if x != before_x
di "AUDIT OLS_ALIAS_RC=" `result' " CHANGED=" r(N)

* Arbitrary fweights should be rejected if fractional.
clear
set obs 200
set seed 1625
gen g=ceil(_n/10)
gen x=rnormal()
gen y=2*x+rnormal()
gen fw=1.5
capture noisily creghdfe y x [fw=fw], absorb(g)
di "AUDIT OLS_FRACTIONAL_FW_RC=" _rc
capture noisily reghdfe y x [fw=fw], absorb(g)
di "AUDIT REF_FRACTIONAL_FW_RC=" _rc

* Range statistics: output aliases and execution branch dependence.
clear
set obs 1000
gen double key = _n
replace key = . in 1000
gen double v = 1
replace v = 1001 in 1000
rangestat (mean) ref=v, interval(key . .)
crangestat (mean) actual=v, interval(key . .)
di "AUDIT RANGE_1000=" actual[1] " REF=" ref[1]
drop in 999
crangestat (mean) small=v, interval(key . .)
di "AUDIT RANGE_999=" small[1]
clonevar before_v=v
capture noisily crangestat (mean) v=v, interval(key -1 1)
local result=_rc
count if v != before_v
di "AUDIT RANGE_ALIAS_RC=" `result' " CHANGED=" r(N)

* cencode validates empty data before honoring output contracts.
clear
set obs 1
gen str3 s="abc"
gen byte target=9
drop in 1
capture noisily encode s, gen(target)
di "AUDIT ENCODE_EXISTING_EMPTY_RC=" _rc
capture noisily cencode s, gen(target)
di "AUDIT CENCODE_EXISTING_EMPTY_RC=" _rc
local tt: type target
di "AUDIT CENCODE_TARGET_TYPE=`tt'"

log close
exit, clear
