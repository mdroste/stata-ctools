ctools audit evidence — September 24, 2026

Companion to SEP24_ASTRA_AUDIT.md. These files document the audited working tree, not the last Git commit. SOURCE_SHA256.json records 420 copied source/configuration/documentation/test inputs. No production implementation was changed for this audit.

The build and Stata tests ran in /tmp/ctools-sep24-audit. The do-files retain those absolute paths. To reproduce elsewhere, copy the audited source and build inputs into a fresh disposable directory, build a fresh plugin there, and replace this path in the do-files. Use the project validation setup and cached fixtures for third-party reference commands. Do not run a stale installed plugin by accident.

All Stata runs on this machine must use the user's wrapper, for example:
/bin/zsh -lic 'oldstata -q -b do "/tmp/ctools-sep24-audit/repro3.do"'
Each completed do-file ends with exit, clear. The wrapper's temporary clock setting explains July 1 timestamps in the logs; the actual audit took place on September 24.

Build used:
make macos-arm LIBOMP_PREFIX=/tmp/ctools-p2-fixes/libomp-arm21 BUILD_REVISION=sep24-audit
The libomp path is an existing machine-local static runtime, not included in this archive. See docs/PLATFORMS.md to provide an appropriate runtime on another machine.

Baseline checks run successfully in the isolated copy:
python3 scripts/sync_release.py --check
python3 validation/check_package.py build --metadata-only
python3 validation/test_p1_native.py
python3 validation/test_p2_native.py
python3 validation/test_sep22_native.py
python3 validation/test_release_gate.py
python3 validation/test_build_contract.py
python3 validation/run_stata_audit.py
The Stata driver itself invokes oldstata. The summary log records 2866 passes, zero failures, 48 expected exclusions and completion of all 20 components. Terminal output for individual Python checks is not archived as a separate transcript.

Reproduction map:
repro1: HDFE convergence, output aliases, range missing-key threshold, empty-data encode; also checks several cases that passed.
repro2: daily Excel dates, PPML Wald statistic, wide CSV headers.
repro3: all explicit sort algorithms, filenames with spaces, merge storage promotion, HDFE coefficient evidence.
repro5: binsreg redundant controls, weight expressions and factor controls, partial multi-variable encode, datetime Excel export.
The exploratory repro4 is omitted because an invalid Stata string-generation expression stopped it early; repro5 contains the corrected complete experiment.

Native harnesses include the audited C implementation directly. On this Apple Silicon machine the small non-OpenMP harnesses can be compiled using:
clang -DSYSTEM=APPLEMAC -std=gnu11 -O1 -g -Wl,-dead_strip -Wl,-undefined,dynamic_lookup -I/path/to/audited/src harness.c -o /tmp/audit_harness
The arena harness needs only -std=gnu11 and the source include path. On Linux use the appropriate SYSTEM definition and linker flags instead.

fault_merge and fault_sample intercept malloc/calloc/free, fail the first ordinary allocation, and record invalid free attempts without crashing. Aligned allocations remain supplied by the source's normal helper. fault_vce demonstrates a zero covariance with no error channel after injected allocation failure. mismatched_key intercepts strcmp and prints the invalid numeric-as-string pointer without dereferencing it. arena_reset retains a pointer to the orphaned block so it can explicitly free it after demonstrating the leak.

noomp_sample deliberately triggers a native memory-safety failure. Compile it without OpenMP, with -fsanitize=address,undefined, and run it only as its own disposable process. It supplies four as the available-thread count and calls the public order-only sample-sort interface on 400001 strings. The archived sanitizer output shows the failing read. Symbolization on this machine printed warnings but resolved the relevant sample-sort and strcmp stack frames. Do not run this defect inside Stata merely to demonstrate a host crash.

The .xlsx and CSV outputs contain only synthetic test data. Native executable files, plugins, private user data, third-party runtimes, and full vendor source trees are not included.
