#include <stdio.h>
#include "stplugin.h"
#include "ctools_types.h"
static ST_plugin mock; ST_plugin *_stata_ = &mock;
#include <string.h>
#include <stdint.h>
static int checked_strcmp(const char *a, const char *b) {
 printf("strcmp would dereference b=%p (numeric 1.0 reinterpreted as pointer)\n", (void *)b);
 return 0;
}
#define strcmp checked_strcmp
#include "cmerge/cmerge_keys.c"
int main(void) {
 char *strings[]={"1"}; double nums[]={1.0};
 stata_variable a={.type=STATA_TYPE_STRING,.nobs=1,.data.str=strings};
 stata_variable b={.type=STATA_TYPE_DOUBLE,.nobs=1,.data.dbl=nums};
 stata_data da={.nobs=1,.nvars=1,.vars=&a}, db={.nobs=1,.nvars=1,.vars=&b};
 printf("comparison=%d\n",cmerge_compare_keys(&da,0,&db,0,1));
}
