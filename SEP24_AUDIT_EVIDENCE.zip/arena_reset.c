#include <stdio.h>
#include <stdint.h>
#include "ctools_arena.c"
int main(void) {
 ctools_arena a; ctools_arena_init(&a,8);
 ctools_arena_alloc(&a,8); ctools_arena_alloc(&a,8);
 CToolsArenaBlock *old_second=a.first->next;
 ctools_arena_reset(&a);
 ctools_arena_alloc(&a,8); ctools_arena_alloc(&a,8);
 printf("original second block retained=%d (expected 1)\n",a.first->next==old_second);
 ctools_arena_free(&a);
 free(old_second); /* recover orphan from test */
}
