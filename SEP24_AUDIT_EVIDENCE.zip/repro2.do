clear all
set more off
set linesize 255
adopath ++ "/tmp/ctools-sep24-audit/build"
capture log close _all
log using "/tmp/ctools-sep24-audit/repro2.log", text replace

* Date round-trip through Excel.
clear
set obs 3
gen double day = mdy(1,1,1960)+_n-1
format day %td
export excel using "/tmp/ctools-sep24-audit/native_dates.xlsx", firstrow(variables) replace
cimport excel using "/tmp/ctools-sep24-audit/native_dates.xlsx", clear firstrow
format day %15.0g
list
capture di "AUDIT DATE_FIRST=" day[1]

* Two-way FE fits need invariant joint Wald tests after reordering collinear regressors.
clear
set obs 600
set seed 92815
gen g=ceil(_n/10)
gen double x=rnormal()
gen double z=rnormal()
gen double zero=0
gen double y=rpoisson(exp(.3+.4*x+.2*z+g/200))
cpplmhdfe y zero x z, absorb(g)
scalar badf=e(F)
test x z
di "AUDIT PPML_F=" badf " JOINT=" r(F)
cpplmhdfe y x z zero, absorb(g)
di "AUDIT PPML_REORDERED_F=" e(F)

* Wide named exports should not substitute generic column names.
clear
set obs 1
forval i=1/1100 {
    gen double long_variable_name_for_test_`i' = `i'
}
cexport delimited using "/tmp/ctools-sep24-audit/wide.csv", replace

log close
exit, clear
