
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "stplugin.h"
#include "ctools_types.h"
#include "ctools_config.h"
static ST_plugin mock;
ST_plugin *_stata_ = &mock;

static int calls, fail_at=1, invalid_frees;
static void *live[200]; static int nlive;
static void *test_malloc(size_t n) {
  if (++calls == fail_at) return NULL;
  void *p=malloc(n); if(p) {memset(p,0xa5,n); live[nlive++]=p;} return p;
}
static void test_free(void *p) {
  if(!p) return;
  for(int i=0;i<nlive;i++) if(live[i]==p) {free(p);live[i]=NULL;return;}
  invalid_frees++;
}
#define malloc test_malloc
#define free test_free

#include "ctools_matrix.c"
int main(void) {
  double X[]={1,2,3}, D[]={1.0/14}, e[]={1,-1,2}, V[]={123};
  ctools_vce_data d={.X_eff=X,.D=D,.resid=e,.N=3,.K=1};
  ctools_vce_robust(&d,1,V);
  printf("robust VCE allocation failure: V=%g, no error return available\n",V[0]);
}
