
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "stplugin.h"
#include "ctools_types.h"
#include "ctools_config.h"
static ST_plugin mock;
ST_plugin *_stata_ = &mock;
int ctools_get_max_threads(void) { return 4; }
static int calls, fail_at=1, invalid_frees;
static void *live[200]; static int nlive;
static void *test_malloc(size_t n) {
  if (++calls == fail_at) return NULL;
  void *p=malloc(n); if(p) {memset(p,0xa5,n); live[nlive++]=p;} return p;
}
static void test_free(void *p) {
  if(!p) return;
  for(int i=0;i<nlive;i++) if(live[i]==p) {free(p);live[i]=NULL;return;}
  invalid_frees++;
}
static void *test_calloc(size_t n, size_t z) {
 void *p=calloc(n,z); if(p) live[nlive++]=p; return p;
}
#define calloc test_calloc
#define malloc test_malloc
#define free test_free

#include "ctools_sort_sample.c"

int main(void) {
  perm_idx_t order[64]; uint64_t keys[64];
  for(int i=0;i<64;i++) {order[i]=i;keys[i]=64-i;}
  int rc=sample_sort_numeric_impl(order,keys,64,4);
  printf("sample injected malloc failure: rc=%d invalid_free_attempts=%d\n",rc,invalid_frees);
  return 0;
}
