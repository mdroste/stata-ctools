clear all
set more off
set linesize 255
adopath ++ "/tmp/ctools-sep24-audit/build"
capture log close _all
log using "/tmp/ctools-sep24-audit/repro3.log", text replace

* Alternate sorting algorithms must order strings lexicographically.
foreach n in 31 32 100 30000 {
  foreach alg in lsd msd timsort sample counting merge ips4o {
    clear
    set obs `n'
    gen str2 key=cond(mod(_n,2),"az","ba")
    gen long id=_n
    capture noisily csort key, algorithm(`alg') nosortedby threads(2)
    local rc=_rc
    count if key < key[_n-1] & _n>1
    di "AUDIT SORT_N=`n' ALG=`alg' RC=`rc' INVERSIONS=" r(N)
  }
}

* Ordinary export paths may contain spaces and option-shaped text.
clear
set obs 2
gen x=_n
capture noisily cexport delimited using "/tmp/ctools-sep24-audit/space name.csv", replace
di "AUDIT EXPORT_SPACE_RC=" _rc
capture confirm file "/tmp/ctools-sep24-audit/space name.csv"
di "AUDIT EXPORT_SPACE_EXISTS_RC=" _rc
capture noisily cexport excel using "/tmp/ctools-sep24-audit/space name.xlsx", replace
di "AUDIT XLSX_SPACE_RC=" _rc
capture confirm file "/tmp/ctools-sep24-audit/space name.xlsx"
di "AUDIT XLSX_SPACE_EXISTS_RC=" _rc

* cmerge must promote shared storage types.
clear
set obs 2
gen byte id=_n
gen double value=1000.125
gen str20 text="abcdefghijklmnopqrst"
save "/tmp/ctools-sep24-audit/using_types.dta", replace
clear
set obs 1
gen byte id=1
gen byte value=.
gen str1 text=""
capture noisily cmerge 1:1 id using "/tmp/ctools-sep24-audit/using_types.dta", update
local rc=_rc
list
di "AUDIT MERGE_TYPES_RC=" `rc'

* OLS iterate() evidence values.
clear
set obs 1000
set seed 742913
gen g = ceil(_n/10)
gen h = ceil(runiform()*50)
gen double x = rnormal() + g/10 + h/5
gen double y = .7*x + g/5 - h/7 + rnormal()
creghdfe y x, absorb(g h) iterate(1) tolerance(1e-14)
di "AUDIT OLS_ITER1_B=" %21.15g _b[x]
creghdfe y x, absorb(g h) tolerance(1e-12)
di "AUDIT OLS_FULL_B=" %21.15g _b[x]

log close
exit, clear
