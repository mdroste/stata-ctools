#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "stplugin.h"
#include "ctools_types.h"
#include "ctools_config.h"
static ST_plugin mock;
ST_plugin *_stata_ = &mock;
int ctools_get_max_threads(void) { return 4; }
#include "ctools_sort_sample.c"
int main(void) {
  size_t N=400001;
  stata_variable var={.type=STATA_TYPE_STRING,.nobs=N};
  var.data.str=malloc(N*sizeof(char *));
  stata_data d={.nobs=N,.nvars=1,.vars=&var};
  d.sort_order=malloc(N*sizeof(perm_idx_t));
  for(size_t i=0;i<N;i++){var.data.str[i]=(i%2)?"az":"ba";d.sort_order[i]=i;}
  int key=1;
  printf("No OpenMP, 4 detected CPUs, string sample sort\n");fflush(stdout);
  int rc=ctools_sort_sample_order_only(&d,&key,1);
  printf("rc=%d\n",rc);
  free(var.data.str);free(d.sort_order);
}
