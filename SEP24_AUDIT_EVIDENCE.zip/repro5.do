clear all
set more off
set linesize 255
adopath ++ "/tmp/ctools-sep24-audit/build"
capture log close _all
log using "/tmp/ctools-sep24-audit/repro5.log", text replace

* Adding a redundant control must preserve adjusted bin means.
clear
set obs 1000
set seed 296519
gen double x=rnormal()
gen double z=x+rnormal()
gen double z2=2*z
gen double y=.3*x+4*z+rnormal()
cbinscatter y x, controls(z) method(binsreg) nograph
matrix one=e(bindata)
cbinscatter y x, controls(z z2) method(binsreg) nograph
matrix dup=e(bindata)
cbinscatter y x, method(binsreg) nograph
matrix raw=e(bindata)
mata: st_numscalar("ddup",max(abs(st_matrix("one")-st_matrix("dup"))))
mata: st_numscalar("draw",max(abs(st_matrix("raw")-st_matrix("dup"))))
di "AUDIT BINSREG_REDUNDANT_CONTROL_DIFF=" ddup " RAW_DIFF=" draw
capture noisily cbinscatter y x [aw=1+abs(z)], nograph
di "AUDIT BIN_WEIGHT_EXPR_RC=" _rc

gen byte category=mod(_n,4)
capture noisily cbinscatter y x, controls(i.category) nograph
di "AUDIT BIN_FACTOR_RC=" _rc

* Failing multi-variable encode should not partially replace earlier variables.
clear
set obs 1
gen str1 a="x"
gen strL b="z"
forvalues i=1/12 {
    quietly replace b=b+b
}
capture noisily cencode a b, replace
local rc=_rc
local at: type a
local bt: type b
di "AUDIT CENCODE_PARTIAL_RC=" `rc' " TYPES=`at',`bt'"

* Datetime time-of-day must survive native Excel export.
clear
set obs 1
gen double timestamp=clock("24sep2026 12:34:56","DMYhms")
format timestamp %tc
cexport excel using "/tmp/ctools-sep24-audit/timeofday.xlsx", firstrow(variables) replace
import excel using "/tmp/ctools-sep24-audit/timeofday.xlsx", clear firstrow
format timestamp %21.0g
list

log close
exit, clear
