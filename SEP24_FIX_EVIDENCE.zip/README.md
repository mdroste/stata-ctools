# Final validation evidence

The final complete Stata run passed 2,877 checks with zero failures and 48 documented matching-SE exclusions. All 23 September 24 native regression groups passed with ASan and UBSan using /usr/bin/clang; OpenMP variants used the locally built libomp 21 runtime.

Additional observed checks passed: release metadata synchronization, package metadata, release-gate fixtures, public-command inventory, four-platform build failure fixtures, macOS ARM/Intel and Windows dependency contracts, and git diff --check. A complete macOS ARM package was staged and validated; its BUILD_INFO.json is included. These outcomes are summarized here; this file is not raw command output.

Build revision: sep24-fixes; package version: 1.0.2. Stata ran with the mandatory oldstata wrapper. July 1 log timestamps are due to its temporary clock adjustment. Builds contain compiler warnings, and static analysis reports supporting review evidence rather than a warning-free claim.

Linux was not built locally (Docker daemon unavailable; no Linux cross-compiler). Intel and Windows plugins were cross-compiled and checked, but not executed within Stata on those operating systems. This archive is evidence, not a multi-platform release.
